# 🎮 WarungGG.my.id – Saldoin.my.id Website Top Up Game & Produk Digital

Selamat datang di repositori resmi WarungGG – tempat isi ulang produk digital seperti Diamond ML, UC PUBG, Pulsa, dan lainnya dengan cepat, murah, dan terpercaya!

🌐 Website: [[https://audyalvasyha.github.io/warunggg.my.id](https://audyalvasyha.github.io/warunggg.my.id/)]

---

## ✨ Fitur Unggulan

- ✅ Top Up Game Mobile Legends, PUBG, Free Fire, Roblox, dll.
- 📱 Support semua metode pembayaran (Dana, OVO, ShopeePay, QRIS, Bank Transfer, dll)
- ⚡️ Responsive dan ringan, cocok diakses dari semua perangkat
- 🔄 Navigasi AJAX tanpa reload halaman
- 📦 Data produk dinamis via file JSON
- 📄 Artikel & edukasi seputar top up game
- 🔐 Siap dikembangkan menjadi PWA

---

## 🛠️ Teknologi yang Digunakan

- HTML, CSS, JavaScript
- jQuery (AJAX Navigation)
- JSON sebagai data source dinamis
- Hosted via GitHub Pages

---

## 📂 Struktur Proyek

